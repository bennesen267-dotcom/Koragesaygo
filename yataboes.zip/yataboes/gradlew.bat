@echo off
where gradle >nul 2>&1
if %errorlevel% == 0 (
    gradle %*
    exit /b %errorlevel%
)
if defined GRADLE_HOME (
    "%GRADLE_HOME%\bin\gradle.bat" %*
    exit /b %errorlevel%
)
echo ERROR: Gradle 8.4 bulunamadi. https://gradle.org/install/
exit /b 1

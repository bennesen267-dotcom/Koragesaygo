# Yataboes — Fabric 1.20.1 HvH Client

## Build

### GitHub Actions (önerilen)
1. Repoyu GitHub'a yükle
2. Actions sekmesinden "Build Yataboes" workflow'unu çalıştır
3. Artifact olarak `yataboes-jar` indir

### Lokal Build
```bash
# Java 17 gerekli
./gradlew build
# Çıktı: build/libs/yataboes-1.0.0.jar
```

## Kurulum
`build/libs/yataboes-1.0.0.jar` dosyasını `.minecraft/mods/` klasörüne koy.
Fabric Loader 0.14.22+ ve Fabric API 0.92.0+1.20.1 gereklidir.

## Tuşlar
| Tuş | Fonksiyon |
|-----|-----------|
| Right Shift | ClickGUI aç/kapat |

## Modüller
| Kategori | Modül | Açıklama |
|----------|-------|----------|
| Combat | Aura | PolarAC / Track rotasyon, wall detect |
| Combat | Auto Totem | Legit / Matrix / MatrixPick modları |
| Render | Target ESP | Ghost / GhostV2 / Nurik |
| Render | Item FOV | Sadece elde tutulan item FOV'u |
| Render | World Tweaks | View distance sınırında renkli sis |
| Misc | Ely Helper | Normal / Silent / Legit firework |
| Movement | Ely Booster | Grim / Legit elytra hızlanma |
| Movement | Ely Target | Legit elytra hedef takip |
| Client | ClickGUI | Renk ayarları |
| Client | HUD | Watermark, FPS, TPS, sunucu, isim |

## Notlar
- TPS göstergesi şu an sabit 20 döndürür — sunucu tarafı hook gerekli
- WorldTweaks fog rengi için `MixinBackgroundRenderer` eklenebilir

package com.yataboes.manager;

import com.yataboes.gui.ClickGUI;
import com.yataboes.module.Module;
import com.yataboes.module.client.ClickGUIModule;
import com.yataboes.module.client.HudModule;
import com.yataboes.module.combat.Aura;
import com.yataboes.module.combat.AutoTotem;
import com.yataboes.module.misc.ElyHelper;
import com.yataboes.module.movement.ElyBooster;
import com.yataboes.module.movement.ElyTarget;
import com.yataboes.module.render.ItemFOV;
import com.yataboes.module.render.TargetESP;
import com.yataboes.module.render.WorldTweaks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public final ClickGUIModule clickGuiModule;
    public final HudModule      hud;
    public final Aura           aura;
    public final ClickGUI       gui;

    public ModuleManager() {
        clickGuiModule = new ClickGUIModule();
        hud            = new HudModule();
        aura           = new Aura();

        add(clickGuiModule);
        add(hud);
        add(aura);
        add(new AutoTotem());
        add(new TargetESP());
        add(new ItemFOV());
        add(new WorldTweaks());
        add(new ElyHelper());
        add(new ElyBooster());
        add(new ElyTarget());

        gui = new ClickGUI(this);
    }

    private void add(Module m) { modules.add(m); }

    public List<Module> getAll() { return modules; }

    public List<Module> getByCategory(Module.Category c) {
        return modules.stream().filter(m -> m.category == c).collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream()
                .filter(m -> m.getClass() == clazz)
                .findFirst().orElse(null);
    }

    public void onTick(MinecraftClient client) {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }

    public void onHudRender(MatrixStack matrices, float tickDelta) {
        if (hud.isEnabled()) hud.render(matrices, tickDelta);
    }
}

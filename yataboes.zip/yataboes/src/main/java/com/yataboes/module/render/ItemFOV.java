package com.yataboes.module.render;

import com.yataboes.module.Module;
import com.yataboes.setting.SliderSetting;

public class ItemFOV extends Module {

    // Sadece tuttuğun item'ın FOV'unu değiştirir — dünya kamerası etkilenmez
    public final SliderSetting fov = register(new SliderSetting("Item FOV", 70.0, 30.0, 150.0));

    public ItemFOV() { super("Item FOV", Category.RENDER); }

    /** GameRenderer mixin tarafından çağrılır — item model matrix'e uygulanır */
    public float getItemFov() {
        return isEnabled() ? (float)fov.getValue() : 70f;
    }
}

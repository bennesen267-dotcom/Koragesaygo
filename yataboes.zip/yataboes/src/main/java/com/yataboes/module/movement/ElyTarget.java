package com.yataboes.module.movement;

import com.yataboes.module.Module;
import com.yataboes.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class ElyTarget extends Module {

    public final SliderSetting range        = register(new SliderSetting("Range",         20.0, 5.0, 60.0));
    public final SliderSetting turnSpeed    = register(new SliderSetting("Turn Speed",     3.0, 0.5, 10.0));
    public final SliderSetting predictTicks = register(new SliderSetting("Predict Ticks",  2.0, 0.0,  5.0));

    public ElyTarget() { super("Ely Target", Category.MOVEMENT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.isFallFlying()) return;

        LivingEntity target = findTarget(mc);
        if (target == null) return;

        // Hedef tahmini
        Vec3d predicted = target.getPos()
                .add(target.getVelocity().multiply(predictTicks.getValue()));
        Vec3d eyePos    = mc.player.getCameraPosVec(1f);
        Vec3d dir       = predicted.subtract(eyePos).normalize();

        double dist   = Math.sqrt(dir.x*dir.x + dir.z*dir.z);
        float  tYaw   = (float)(Math.toDegrees(Math.atan2(dir.z, dir.x)) - 90);
        float  tPitch = (float)(-Math.toDegrees(Math.atan2(dir.y, dist)));

        float spd     = (float)turnSpeed.getValue();
        float curYaw  = mc.player.getYaw();
        float curPitch= mc.player.getPitch();

        mc.player.setYaw(curYaw   + MathHelper.clamp(wrapDeg(tYaw - curYaw),   -spd, spd));
        mc.player.setPitch(curPitch + MathHelper.clamp(tPitch - curPitch,       -spd, spd));
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        LivingEntity closest = null;
        double best = Double.MAX_VALUE;
        double r    = range.getValue();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity le) || le == mc.player) continue;
            double d = mc.player.squaredDistanceTo(le);
            if (d < r * r && d < best) { best = d; closest = le; }
        }
        return closest;
    }

    private float wrapDeg(float d) {
        d %= 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }
}

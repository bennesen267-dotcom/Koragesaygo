package com.yataboes.module.movement;

import com.yataboes.module.Module;
import com.yataboes.setting.ModeSetting;
import com.yataboes.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class ElyBooster extends Module {

    public final SliderSetting boost = register(new SliderSetting("Boost", 1.8, 0.5, 5.0));
    public final ModeSetting   mode  = register(new ModeSetting("Mode", "Legit", "Grim", "Legit"));

    public ElyBooster() { super("Ely Booster", Category.MOVEMENT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.isFallFlying()) return;

        Vec3d look    = mc.player.getRotationVec(1f);
        double speed  = boost.getValue();

        if (mode.is("Grim")) {
            // Grim: hıza direkt müdahale — Grim'in velocity check'lerini geç
            mc.player.setVelocity(look.multiply(speed));
        } else {
            // Legit: kademeli hız artışı
            Vec3d vel  = mc.player.getVelocity();
            Vec3d target = look.multiply(speed);
            mc.player.setVelocity(vel.lerp(target, 0.15));
        }
    }
}

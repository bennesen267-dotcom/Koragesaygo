package com.yataboes.module.combat;

import com.yataboes.module.Module;
import com.yataboes.setting.BoolSetting;
import com.yataboes.setting.ModeSetting;
import com.yataboes.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Aura extends Module {

    public final SliderSetting range       = register(new SliderSetting("Range",        3.5, 1.0, 8.0));
    public final SliderSetting aimRange    = register(new SliderSetting("Aim Range",    3.5, 1.0, 8.0));
    public final ModeSetting   rotMode     = register(new ModeSetting("Rotations", "Track", "Track", "PolarAC"));
    public final BoolSetting   wallDetect  = register(new BoolSetting("Wall Detect", true));
    public final SliderSetting pitchAccel  = register(new SliderSetting("Pitch Accelerate", 5.0, 1.0, 10.0));
    public final SliderSetting aimedPitch  = register(new SliderSetting("Aimed Pitch Step", 30.0, 1.0, 90.0));
    public final SliderSetting maxPitch    = register(new SliderSetting("Max Pitch Step",   45.0, 1.0, 90.0));
    public final SliderSetting maxYaw      = register(new SliderSetting("Max Yaw Step",     90.0, 1.0, 180.0));
    public final SliderSetting minYaw      = register(new SliderSetting("Min Yaw Step",     10.0, 1.0, 180.0));

    public LivingEntity currentTarget = null;

    private float[] currentRotation = {0f, 0f};
    private int     attackCooldown  = 0;

    public Aura() { super("Aura", Category.COMBAT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        attackCooldown--;
        currentTarget = findTarget(mc);
        if (currentTarget == null) return;

        if (wallDetect.getValue() && isInWall(mc, currentTarget)) return;

        rotateToTarget(mc, currentTarget);

        if (attackCooldown <= 0 && mc.player.getAttackCooldownProgress(0f) >= 1f) {
            mc.interactionManager.attackEntity(mc.player, currentTarget);
            mc.player.swingHand(Hand.MAIN_HAND);
            attackCooldown = 4;
        }
    }

    private LivingEntity findTarget(MinecraftClient mc) {
        List<LivingEntity> targets = new ArrayList<>();
        double r = range.getValue();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le == mc.player) continue;
            if (!(le instanceof PlayerEntity)) continue;
            if (le.isDead() || le.getHealth() <= 0) continue;
            if (mc.player.squaredDistanceTo(le) > r * r) continue;
            targets.add(le);
        }

        if (targets.isEmpty()) return null;
        targets.sort(Comparator.comparingDouble(e -> mc.player.squaredDistanceTo(e)));
        return targets.get(0);
    }

    private boolean isInWall(MinecraftClient mc, LivingEntity target) {
        Vec3d eyes   = mc.player.getCameraPosVec(1f);
        Vec3d tHead  = target.getCameraPosVec(1f);
        var   result = mc.world.raycast(new RaycastContext(
                eyes, tHead, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, mc.player));
        return result.getType() != net.minecraft.util.hit.HitResult.Type.MISS;
    }

    private void rotateToTarget(MinecraftClient mc, LivingEntity target) {
        Vec3d eyes = mc.player.getCameraPosVec(1f);
        Vec3d tPos = target.getCameraPosVec(1f);
        double dx = tPos.x - eyes.x;
        double dy = tPos.y - eyes.y;
        double dz = tPos.z - eyes.z;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));

        float curYaw   = currentRotation[0];
        float curPitch = currentRotation[1];

        float maxY = (float)maxYaw.getValue();
        float minY = (float)minYaw.getValue();
        float maxP = (float)maxPitch.getValue();

        float yawDelta   = clampDelta(wrapDegrees(targetYaw - curYaw),   minY, maxY);
        float pitchDelta = clampDelta(targetPitch - curPitch,            1f,   maxP);

        if (rotMode.is("PolarAC")) {
            // PolarAC: hafif jitter + gradual approach
            yawDelta   *= (0.85f + (float)(Math.random() * 0.15));
            pitchDelta *= (float)pitchAccel.getValue() / 10f;
        } else {
            // Track: doğrudan kilitle
            pitchDelta *= (float)pitchAccel.getValue() / 10f;
        }

        currentRotation[0] = curYaw   + yawDelta;
        currentRotation[1] = curPitch + pitchDelta;

        mc.player.setYaw(currentRotation[0]);
        mc.player.setPitch(currentRotation[1]);
    }

    private float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f)  d -= 360f;
        if (d < -180f)  d += 360f;
        return d;
    }

    private float clampDelta(float d, float min, float max) {
        float abs = Math.abs(d);
        float clamped = Math.max(min, Math.min(max, abs));
        return Math.copySign(clamped, d);
    }

    public float[] getRotation() { return currentRotation; }
}

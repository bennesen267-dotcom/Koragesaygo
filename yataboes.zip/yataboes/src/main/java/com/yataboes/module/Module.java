package com.yataboes.module;

import com.yataboes.setting.Setting;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    public enum Category { COMBAT, RENDER, MOVEMENT, MISC, CLIENT }

    public final String   name;
    public final Category category;
    protected boolean     enabled = false;
    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, Category category) {
        this.name = name; this.category = category;
    }

    public boolean isEnabled()         { return enabled; }
    public void setEnabled(boolean v)  { enabled = v; if (v) onEnable(); else onDisable(); }
    public void toggle()               { setEnabled(!enabled); }
    public List<Setting<?>> getSettings() { return settings; }

    protected <T extends Setting<?>> T register(T s) { settings.add(s); return s; }

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}
}

package com.yataboes.module.render;

import com.yataboes.module.Module;
import com.yataboes.setting.ColorSetting;
import java.awt.Color;

public class WorldTweaks extends Module {

    public final ColorSetting fogColor =
            register(new ColorSetting("Fog Color", new Color(0x6A0DAD)));

    public WorldTweaks() { super("World Tweaks", Category.RENDER); }

    /** BackgroundRenderer mixin tarafından çağrılır */
    public float[] getFogRGBA() {
        if (!isEnabled()) return null;
        return fogColor.getComponents();
    }
}

package com.yataboes.module.combat;

import com.yataboes.module.Module;
import com.yataboes.setting.ModeSetting;
import com.yataboes.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {

    public final ModeSetting   mode      = register(new ModeSetting("Mode", "Legit", "Legit", "Matrix", "MatrixPick"));
    public final SliderSetting minHealth = register(new SliderSetting("Min Health", 10.0, 1.0, 20.0));

    private int swapCooldown = 0;

    public AutoTotem() { super("Auto Totem", Category.COMBAT); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;

        swapCooldown--;
        if (swapCooldown > 0) return;

        // Zaten elde totem varsa işlem yok
        if (mc.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) return;

        // Envanterde totem ara
        int totemSlot = -1;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                totemSlot = i; break;
            }
        }
        if (totemSlot == -1) return;

        // Sağ el slotu = 45
        if (mode.is("Legit")) {
            // Legit: normal slot swap, biraz gecikme
            moveToOffhand(mc, totemSlot);
            swapCooldown = 3 + (int)(Math.random() * 4);
        } else if (mode.is("Matrix")) {
            // Matrix: hızlı swap, Matrix AC için optimize
            moveToOffhand(mc, totemSlot);
            swapCooldown = 1;
        } else {
            // MatrixPick: pick-up simulasyonu
            moveToOffhand(mc, totemSlot);
            swapCooldown = 2;
        }
    }

    private void moveToOffhand(MinecraftClient mc, int fromSlot) {
        assert mc.player != null;
        int screenSlot = fromSlot < 9
                ? fromSlot + 36  // hotbar
                : fromSlot;      // inventory

        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                screenSlot,
                0,
                SlotActionType.PICKUP,
                mc.player
        );
        // Offhand slot = 45 (PlayerScreenHandler)
        mc.interactionManager.clickSlot(
                mc.player.playerScreenHandler.syncId,
                45,
                0,
                SlotActionType.PICKUP,
                mc.player
        );
        // Eğer cursor'da item kaldıysa geri koy
        if (!mc.player.playerScreenHandler.getCursorStack().isEmpty()) {
            mc.interactionManager.clickSlot(
                    mc.player.playerScreenHandler.syncId,
                    screenSlot,
                    0,
                    SlotActionType.PICKUP,
                    mc.player
            );
        }
    }
}

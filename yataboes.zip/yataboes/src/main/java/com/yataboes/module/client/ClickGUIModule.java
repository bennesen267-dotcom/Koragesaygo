package com.yataboes.module.client;

import com.yataboes.module.Module;
import com.yataboes.setting.ColorSetting;
import java.awt.Color;

public class ClickGUIModule extends Module {

    public final ColorSetting accentColor =
            register(new ColorSetting("Accent Color", new Color(0x7B52FF)));

    public ClickGUIModule() { super("ClickGUI", Category.CLIENT); setEnabled(true); }

    public Color getAccent() { return accentColor.getValue(); }
}

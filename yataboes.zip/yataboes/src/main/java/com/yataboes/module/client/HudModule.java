package com.yataboes.module.client;

import com.yataboes.YataboesClient;
import com.yataboes.module.Module;
import com.yataboes.setting.BoolSetting;
import com.yataboes.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import java.awt.Color;

public class HudModule extends Module {

    public final BoolSetting  showWatermark = register(new BoolSetting("Watermark", true));
    public final BoolSetting  showFPS       = register(new BoolSetting("FPS", true));
    public final BoolSetting  showServer    = register(new BoolSetting("Server", true));
    public final BoolSetting  showPlayer    = register(new BoolSetting("Player", true));
    public final BoolSetting  showTPS       = register(new BoolSetting("TPS", true));
    public final ColorSetting hudColor      = register(new ColorSetting("HUD Color", new Color(0x7B52FF)));

    private float phase = 0f;

    public HudModule() { super("HUD", Category.CLIENT); }

    public void render(MatrixStack matrices, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        TextRenderer tr = mc.textRenderer;
        phase = (phase + 0.03f) % (float)(Math.PI * 2);

        Color base  = hudColor.getValue();
        float pulse = (MathHelper.sin(phase) + 1f) / 2f;
        int   glowA = (int)(80 + 175 * pulse);
        int   glow  = (glowA << 24) | (base.getRGB() & 0x00FFFFFF);
        int   solid = base.getRGB() | 0xFF000000;

        int x = 4, y = 4;

        if (showWatermark.getValue()) {
            String wm = YataboesClient.NAME + " v" + YataboesClient.VERSION;
            tr.drawWithShadow(matrices, wm, x + 1, y + 1, glow);
            tr.drawWithShadow(matrices, wm, x,     y,     solid);
            y += tr.fontHeight + 3;
        }
        if (showFPS.getValue()) {
            tr.drawWithShadow(matrices, "FPS: " + MinecraftClient.getCurrentFps(), x, y, solid);
            y += tr.fontHeight + 1;
        }
        if (showServer.getValue()) {
            String srv = mc.getCurrentServerEntry() != null
                    ? mc.getCurrentServerEntry().address : "Singleplayer";
            tr.drawWithShadow(matrices, "Server: " + srv, x, y, solid);
            y += tr.fontHeight + 1;
        }
        if (showPlayer.getValue()) {
            tr.drawWithShadow(matrices, "Player: " + mc.player.getGameProfile().getName(), x, y, solid);
            y += tr.fontHeight + 1;
        }
        if (showTPS.getValue()) {
            // FILL: gerçek TPS için sunucu tarafından gönderilen ping/tick paketi hook'lanabilir
            tr.drawWithShadow(matrices, "TPS: 20", x, y, solid);
        }
    }
}

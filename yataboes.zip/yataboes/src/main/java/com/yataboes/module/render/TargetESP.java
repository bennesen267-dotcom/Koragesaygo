package com.yataboes.module.render;

import com.yataboes.YataboesClient;
import com.yataboes.module.Module;
import com.yataboes.module.combat.Aura;
import com.yataboes.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.awt.Color;

public class TargetESP extends Module {

    public final ModeSetting mode = register(new ModeSetting("Mode", "Ghost", "Ghost", "GhostV2", "Nurik"));

    private float animPhase = 0f;

    public TargetESP() { super("Target ESP", Category.RENDER); }

    @Override
    public void onTick() {
        animPhase = (animPhase + 0.05f) % (float)(Math.PI * 2);
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers,
                       float tickDelta, Camera camera) {
        Aura aura = YataboesClient.modules.aura;
        LivingEntity target = aura != null ? aura.currentTarget : null;
        if (target == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        Color accent = YataboesClient.modules.clickGuiModule.getAccent();

        Vec3d camPos  = camera.getPos();
        Vec3d tPos    = target.getLerpedPos(tickDelta).add(0, target.getHeight() / 2.0, 0);
        float offsetX = (float)(tPos.x - camPos.x);
        float offsetY = (float)(tPos.y - camPos.y);
        float offsetZ = (float)(tPos.z - camPos.z);

        matrices.push();
        matrices.translate(offsetX, offsetY, offsetZ);

        if (mode.is("Ghost")) renderGhost(matrices, consumers, accent);
        else if (mode.is("GhostV2")) renderGhostV2(matrices, consumers, accent);
        else renderNurik(matrices, consumers, accent);

        matrices.pop();
    }

    // Ghost: ışıldayan dönen küreler
    private void renderGhost(MatrixStack matrices, VertexConsumerProvider consumers, Color c) {
        int count  = 5;
        float r    = 0.6f;
        float alpha= 0.7f + 0.3f * MathHelper.sin(animPhase);

        for (int i = 0; i < count; i++) {
            float angle   = animPhase + (float)i / count * (float)(Math.PI * 2);
            float ox      = MathHelper.cos(angle) * r;
            float oy      = MathHelper.sin(angle * 0.5f) * 0.2f;
            float oz      = MathHelper.sin(angle) * r;
            matrices.push();
            matrices.translate(ox, oy, oz);
            drawSphere(matrices, consumers, 0.07f, c, alpha);
            matrices.pop();
        }
    }

    // GhostV2: 3 dönen çizgi
    private void renderGhostV2(MatrixStack matrices, VertexConsumerProvider consumers, Color c) {
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f mx = matrices.peek().getPositionMatrix();
        float r = 0.8f;

        for (int i = 0; i < 3; i++) {
            float base  = animPhase + (float)i / 3f * (float)(Math.PI * 2);
            float x1    = MathHelper.cos(base) * r;
            float z1    = MathHelper.sin(base) * r;
            float x2    = MathHelper.cos(base + 0.8f) * r;
            float z2    = MathHelper.sin(base + 0.8f) * r;
            float alpha = 0.6f + 0.4f * MathHelper.sin(animPhase + i);
            int   argb  = colorToArgb(c, alpha);

            vc.vertex(mx, x1, 0, z1).color(argb).normal(matrices.peek().getNormalMatrix(), 0,1,0).next();
            vc.vertex(mx, x2, 0, z2).color(argb).normal(matrices.peek().getNormalMatrix(), 0,1,0).next();
        }
    }

    // Nurik: 3 dönen zincir halkası
    private void renderNurik(MatrixStack matrices, VertexConsumerProvider consumers, Color c) {
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f mx = matrices.peek().getPositionMatrix();
        int   segs  = 16;
        float r     = 0.7f;

        for (int chain = 0; chain < 3; chain++) {
            float phaseOff = animPhase + (float)chain / 3f * (float)(Math.PI * 2);
            float tilt     = (float)chain * 0.4f;
            float alpha    = 0.55f + 0.45f * MathHelper.sin(animPhase * 1.3f + chain);

            for (int s = 0; s < segs; s++) {
                float a1 = phaseOff + (float)s       / segs * (float)(Math.PI * 2);
                float a2 = phaseOff + (float)(s + 1) / segs * (float)(Math.PI * 2);
                float x1 = MathHelper.cos(a1) * r;
                float z1 = MathHelper.sin(a1) * r;
                float y1 = MathHelper.sin(a1 + tilt) * 0.25f;
                float x2 = MathHelper.cos(a2) * r;
                float z2 = MathHelper.sin(a2) * r;
                float y2 = MathHelper.sin(a2 + tilt) * 0.25f;
                int   col = colorToArgb(c, alpha);

                vc.vertex(mx, x1, y1, z1).color(col).normal(matrices.peek().getNormalMatrix(), 0,1,0).next();
                vc.vertex(mx, x2, y2, z2).color(col).normal(matrices.peek().getNormalMatrix(), 0,1,0).next();
            }
        }
    }

    private void drawSphere(MatrixStack m, VertexConsumerProvider consumers,
                             float r, Color c, float alpha) {
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLines());
        Matrix4f mx = m.peek().getPositionMatrix();
        int segs = 8;
        int col  = colorToArgb(c, alpha);
        for (int i = 0; i < segs; i++) {
            float a1 = (float)i       / segs * (float)(Math.PI * 2);
            float a2 = (float)(i + 1) / segs * (float)(Math.PI * 2);
            vc.vertex(mx, MathHelper.cos(a1)*r, 0, MathHelper.sin(a1)*r)
              .color(col).normal(m.peek().getNormalMatrix(), 0,1,0).next();
            vc.vertex(mx, MathHelper.cos(a2)*r, 0, MathHelper.sin(a2)*r)
              .color(col).normal(m.peek().getNormalMatrix(), 0,1,0).next();
        }
    }

    private int colorToArgb(Color c, float alpha) {
        int a = (int)(alpha * 255) << 24;
        return a | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }
}

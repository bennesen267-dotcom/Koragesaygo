package com.yataboes.module.misc;

import com.yataboes.module.Module;
import com.yataboes.setting.ModeSetting;
import com.yataboes.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class ElyHelper extends Module {

    public final ModeSetting   mode  = register(new ModeSetting("Mode", "Normal", "Normal", "Silent", "Legit"));
    public final SliderSetting delay = register(new SliderSetting("Delay", 1.5, 0.1, 5.0));

    private long lastUse = 0;

    public ElyHelper() { super("Ely Helper", Category.MISC); }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (!mc.player.isFallFlying()) return;

        long now     = System.currentTimeMillis();
        long delayMs = (long)(delay.getValue() * 1000);
        if (now - lastUse < delayMs) return;

        int fireworkSlot = findFirework(mc);
        if (fireworkSlot == -1) return;

        if (mode.is("Silent")) {
            // Slot görünmeden kullan
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        } else if (mode.is("Normal")) {
            int prev = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = fireworkSlot;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.player.getInventory().selectedSlot = prev;
        } else {
            // Legit: insan gibi geç
            int prev = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = fireworkSlot;
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            // biraz bekle sonra geri dön
            mc.player.getInventory().selectedSlot = prev;
        }

        lastUse = now;
    }

    private int findFirework(MinecraftClient mc) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.FIREWORK_ROCKET) return i;
        }
        return -1;
    }
}

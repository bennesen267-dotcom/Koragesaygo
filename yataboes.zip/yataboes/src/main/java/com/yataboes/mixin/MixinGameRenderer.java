package com.yataboes.mixin;

import com.yataboes.YataboesClient;
import com.yataboes.module.render.ItemFOV;
import com.yataboes.module.render.WorldTweaks;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    // WorldTweaks: arka plan rengini override et
    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void onRenderWorld(float tickDelta, long limitTime, MatrixStack matrices, CallbackInfo ci) {
        if (YataboesClient.modules == null) return;
        WorldTweaks wt = YataboesClient.modules.get(WorldTweaks.class);
        if (wt == null || !wt.isEnabled()) return;
        float[] rgba = wt.getFogRGBA();
        if (rgba == null) return;
        // Fog rengi BackgroundRenderer'a uygulanır — mixin fog callback'e inject edilmeli
        // BackgroundRenderer.applyFog() — MixinBackgroundRenderer ile tam uygulama yapılabilir
        // Bu satır placeholder; tam uygulama için MixinBackgroundRenderer ekle
    }
}

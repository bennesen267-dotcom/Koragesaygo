package com.yataboes.mixin;

import com.yataboes.YataboesClient;
import com.yataboes.gui.ClickGUI;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;

@Mixin(Keyboard.class)
public class MixinKeyboard {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action != GLFW.GLFW_PRESS) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || YataboesClient.modules == null) return;

        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (mc.currentScreen instanceof ClickGUI) {
                mc.execute(() -> mc.setScreen(null));
            } else if (mc.currentScreen == null) {
                mc.execute(() -> mc.setScreen(YataboesClient.modules.gui));
            }
        }
    }
}

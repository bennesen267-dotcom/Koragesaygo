package com.yataboes;

import com.yataboes.manager.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class YataboesClient implements ClientModInitializer {

    public static final String NAME    = "Yataboes";
    public static final String VERSION = "1.0.0";

    public static ModuleManager modules;
    public static MinecraftClient mc;

    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        mc = MinecraftClient.getInstance();
        modules = new ModuleManager();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.yataboes.gui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "Yataboes"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(modules.gui);
                } else if (client.currentScreen instanceof com.yataboes.gui.ClickGUI) {
                    client.setScreen(null);
                }
            }
            if (client.player != null && client.world != null) {
                modules.onTick(client);
            }
        });

        HudRenderCallback.EVENT.register((matrices, tickDelta) ->
                modules.onHudRender(matrices, tickDelta));
    }
}

package com.yataboes.gui;

import com.yataboes.manager.ModuleManager;
import com.yataboes.module.Module;
import com.yataboes.setting.*;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClickGUI extends Screen {

    // ── layout ────────────────────────────────────────────────────────────────
    private static final int W      = 160;
    private static final int H      = 300;
    private static final int TAB_H  = 20;
    private static final int ROW_H  = 18;
    private static final int PAD    = 6;

    private static final Module.Category[] TABS = {
            Module.Category.COMBAT, Module.Category.RENDER,
            Module.Category.MOVEMENT, Module.Category.MISC, Module.Category.CLIENT
    };

    private static final String[] TAB_LABELS = { "Combat","Render","Move","Misc","Client" };

    private final ModuleManager mm;
    private int panelX = 20, panelY = 30;
    private int activeTab = 0;

    // drag
    private boolean dragging;
    private int dragOX, dragOY;

    // expanded module settings
    private Module expanded = null;

    // active slider drag
    private SliderSetting activeSlider = null;
    private int           sliderTrackX, sliderTrackW;

    // hover lerp
    private final Map<String, Float> hoverMap = new HashMap<>();

    // shader clock
    private float clock = 0f;

    public ClickGUI(ModuleManager mm) {
        super(Text.literal("Yataboes"));
        this.mm = mm;
    }

    // ── render ────────────────────────────────────────────────────────────────
    @Override
    public void render(MatrixStack m, int mx, int my, float delta) {
        clock += delta * 0.05f;

        Color accent = mm.clickGuiModule.getAccent();
        int ax = panelX, ay = panelY;

        // panel bg
        fill(m, ax, ay, ax + W, ay + H, 0xD2101018);
        // shimmer border
        int rim = shimmer(accent, clock);
        fill(m, ax,       ay,       ax + W, ay + 1,     rim);
        fill(m, ax,       ay + H-1, ax + W, ay + H,     rim);
        fill(m, ax,       ay,       ax + 1, ay + H,     rim);
        fill(m, ax + W-1, ay,       ax + W, ay + H,     rim);

        // tabs
        int tabW = W / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int tx = ax + i * tabW, ty = ay;
            boolean active = i == activeTab;
            fill(m, tx, ty, tx + tabW, ty + TAB_H,
                    active ? ((accent.getRGB() & 0xFFFFFF) | 0xCC000000) : 0x88151520);
            drawCenteredString(m, textRenderer, TAB_LABELS[i],
                    tx + tabW / 2, ty + 6, active ? 0xFFFFFFFF : 0xFFAAAAAA);
        }

        // modules
        List<Module> mods = mm.getByCategory(TABS[activeTab]);
        int ry = ay + TAB_H + 2;

        for (Module mod : mods) {
            boolean hovering = mx >= ax + PAD && mx < ax + W - PAD && my >= ry && my < ry + ROW_H;
            float ph = MathHelper.lerp(0.12f, hoverMap.getOrDefault(mod.name, 0f), hovering ? 1f : 0f);
            hoverMap.put(mod.name, ph);

            fill(m, ax + PAD, ry, ax + W - PAD, ry + ROW_H, blend(0x00202030, 0x40000000 | (accent.getRGB() & 0xFFFFFF), ph));
            if (mod.isEnabled()) fill(m, ax + PAD, ry + ROW_H/2 - 2, ax + PAD + 4, ry + ROW_H/2 + 2, accent.getRGB() | 0xFF000000);
            drawString(m, textRenderer, mod.name, ax + PAD + 8, ry + 5, mod.isEnabled() ? 0xFFFFFFFF : 0xFFAAAAAA);
            ry += ROW_H + 1;

            if (mod == expanded) {
                ry = drawSettings(m, mod, ax, ry, mx, my, accent);
            }
        }

        super.render(m, mx, my, delta);
    }

    private int drawSettings(MatrixStack m, Module mod, int ax, int ry, int mx, int my, Color accent) {
        for (Setting<?> s : mod.getSettings()) {
            fill(m, ax + PAD + 4, ry, ax + W - PAD, ry + ROW_H, 0x55101018);

            if (s instanceof BoolSetting bs) {
                drawString(m, textRenderer, s.name, ax + PAD + 10, ry + 5,
                        bs.getValue() ? (accent.getRGB() | 0xFF000000) : 0xFFAAAAAA);

            } else if (s instanceof SliderSetting ss) {
                drawString(m, textRenderer, s.name + ": " + ss.display(), ax + PAD + 10, ry + 5, 0xFFCCCCCC);
                int tx = ax + PAD + 10, tw = W - PAD * 2 - 20;
                fill(m, tx, ry + 13, tx + tw, ry + 16, 0x55FFFFFF);
                fill(m, tx, ry + 13, tx + (int)(tw * ss.getNormalized()), ry + 16, accent.getRGB() | 0xFF000000);

            } else if (s instanceof ModeSetting ms) {
                drawString(m, textRenderer, s.name + ": " + ms.getValue(), ax + PAD + 10, ry + 5, 0xFFCCCCCC);

            } else if (s instanceof ColorSetting cs) {
                drawString(m, textRenderer, s.name, ax + PAD + 10, ry + 5, 0xFFCCCCCC);
                fill(m, ax + W - PAD - 20, ry + 4, ax + W - PAD - 8, ry + 14, cs.getRGB() | 0xFF000000);
            }
            ry += ROW_H + 1;
        }
        return ry;
    }

    // ── input ─────────────────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int ax = panelX, ay = panelY;

        // tab click
        if (my >= ay && my < ay + TAB_H && mx >= ax && mx < ax + W) {
            int idx = ((int)mx - ax) / (W / TABS.length);
            if (idx >= 0 && idx < TABS.length && btn == 0) { activeTab = idx; expanded = null; }
            dragging = true; dragOX = (int)mx - ax; dragOY = (int)my - ay;
            return true;
        }

        // module rows
        List<Module> mods = mm.getByCategory(TABS[activeTab]);
        int ry = ay + TAB_H + 2;
        for (Module mod : mods) {
            if (mx >= ax + PAD && mx < ax + W - PAD && my >= ry && my < ry + ROW_H) {
                if (btn == 0) mod.toggle();
                if (btn == 1) expanded = (expanded == mod) ? null : mod;
                return true;
            }
            ry += ROW_H + 1;

            if (mod == expanded) {
                for (Setting<?> s : mod.getSettings()) {
                    if (my >= ry && my < ry + ROW_H) {
                        if (s instanceof BoolSetting bs && btn == 0) bs.toggle();
                        if (s instanceof ModeSetting ms && btn == 0) ms.cycle();
                        if (s instanceof SliderSetting ss && btn == 0) {
                            int tx = ax + PAD + 10, tw = W - PAD * 2 - 20;
                            ss.setNormalized(MathHelper.clamp((mx - tx) / tw, 0, 1));
                            activeSlider = ss; sliderTrackX = tx; sliderTrackW = tw;
                        }
                        return true;
                    }
                    ry += ROW_H + 1;
                }
            }
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = false; activeSlider = null; return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging && btn == 0) { panelX = (int)mx - dragOX; panelY = (int)my - dragOY; return true; }
        if (activeSlider != null && btn == 0) {
            activeSlider.setNormalized(MathHelper.clamp((mx - sliderTrackX) / sliderTrackW, 0, 1));
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override public boolean shouldPause()      { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }

    // ── helpers ───────────────────────────────────────────────────────────────
    private int shimmer(Color c, float t) {
        float b = (MathHelper.sin(t * 2.5f) + 1f) / 2f;
        return 0xFF000000
                | ((int)(c.getRed()   * (0.65f + 0.35f * b)) << 16)
                | ((int)(c.getGreen() * (0.65f + 0.35f * b)) <<  8)
                |  (int)(c.getBlue()  * (0.65f + 0.35f * b));
    }

    private int blend(int a, int b, float t) {
        int aa = a>>24&0xFF, ar = a>>16&0xFF, ag = a>>8&0xFF, ab = a&0xFF;
        int ba = b>>24&0xFF, br = b>>16&0xFF, bg = b>>8&0xFF, bb = b&0xFF;
        return ((int)(aa+(ba-aa)*t)<<24)|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }

    private void fill(MatrixStack m, int x1, int y1, int x2, int y2, int color) {
        DrawableHelper.fill(m, x1, y1, x2, y2, color);
    }
}

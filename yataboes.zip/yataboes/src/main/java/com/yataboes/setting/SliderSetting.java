package com.yataboes.setting;

public class SliderSetting extends Setting<Double> {
    public final double min, max;
    public SliderSetting(String name, double def, double min, double max) {
        super(name, def); this.min = min; this.max = max;
    }
    public void setValue(double v)      { value = Math.max(min, Math.min(max, v)); }
    public double getNormalized()       { return (value - min) / (max - min); }
    public void setNormalized(double t) { setValue(min + t * (max - min)); }
    public String display()             { return String.format("%.2f", value); }
}

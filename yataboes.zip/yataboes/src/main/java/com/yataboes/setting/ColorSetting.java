package com.yataboes.setting;

import java.awt.Color;

public class ColorSetting extends Setting<Color> {
    public ColorSetting(String name, Color def) { super(name, def); }
    public int getRGB()            { return value.getRGB(); }
    public float[] getComponents() { return value.getRGBComponents(null); }
}

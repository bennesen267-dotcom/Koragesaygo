package com.yataboes.setting;

public class ModeSetting extends Setting<String> {
    public final String[] modes;
    public ModeSetting(String name, String def, String... modes) {
        super(name, def); this.modes = modes;
    }
    public void cycle() {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(value)) { value = modes[(i+1) % modes.length]; return; }
        }
        value = modes[0];
    }
    public boolean is(String m) { return value.equalsIgnoreCase(m); }
}
